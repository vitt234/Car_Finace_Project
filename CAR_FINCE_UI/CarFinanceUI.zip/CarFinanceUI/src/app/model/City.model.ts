import { Taluka } from "./Taluka.model";

export class City
{
  cityId!: number;
  cityName!: string;
  cityTaluka!: Taluka;
}
