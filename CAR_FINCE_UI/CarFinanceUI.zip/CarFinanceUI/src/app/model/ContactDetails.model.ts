export class ContactDetails {

  contactId: number;
  primaryMobileNo: number;
  alternateMobileNo: number;
  landlineNo: number;
  emailId: string;


}
