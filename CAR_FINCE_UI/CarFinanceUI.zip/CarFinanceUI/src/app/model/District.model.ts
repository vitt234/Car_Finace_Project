import { State } from "./State.model";

export class District {

  districtId!: number;
  districtName!: string;
  districtState!: State;
}
