export class Menu {
    public static menu: Array<any> = [
      {
        admin: [
          {path: "adminbash", title: "Dashbord", icon: "pe-7s-graph", class: "" },
          {path: "city", title: "Create Student", icon: "pe-7s-graph", class: "" },
          {path: "book-list", title: "Student List", icon: "pe-7s-graph", class: "" }
      ],
      emp: [
        {path: "empdash", title: "dashbord", icon: "pe-7s-graph", class: "" },
        {path: "demo", title: "Demmmo", icon: "pe-7s-graph", class: "" },
        {path: "user", title: "user", icon: "pe-7s-graph", class: "" },
    ],

    re: [


      {path: "re", title: "sanction", icon: "reduce_capacity", class: "" }

  ],


  oe: [
    {path: "custDetails", title: "Custmer_Details", icon: "people_alt", class: "" },
    {path: "fileinitiate", title: "File_Inititate", icon: "account_balance_wallet", class: "" },
    {path: "cibilcheck", title: "Cibil_Check", icon: "network_check", class: "" },
],

cm: [


  {path: "cm", title: "Document_verification", icon: "event_note", class: "" }

],
ah: [
  {path: "ah", title: "Sanction-List", icon: "reduce_capacity", class: "" },
  {path: "dis", title: "disbursement-List", icon: "grading", class: "" },

],


      }
    ];
  }
