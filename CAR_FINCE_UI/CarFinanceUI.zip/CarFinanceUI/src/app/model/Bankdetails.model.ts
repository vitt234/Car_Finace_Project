export class Bankdetails
{

  bankid: number;
  bankaccountNumber: string;
  bankAccountHolderName: string;
  accountType: string;
  bankBranch: string;

}
