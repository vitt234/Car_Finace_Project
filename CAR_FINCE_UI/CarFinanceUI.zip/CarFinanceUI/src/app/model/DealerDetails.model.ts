import { Bankdetails } from "./Bankdetails.model";

export class DealerDetails{


  dealerId: number;
  delearName: string;
  bankDetails: Bankdetails;

}
