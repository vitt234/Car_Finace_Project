import { Country } from "./Country.model";

export class State {

  stateId!: number;
  stateName!: string;
  stateCountry!: Country;

}
