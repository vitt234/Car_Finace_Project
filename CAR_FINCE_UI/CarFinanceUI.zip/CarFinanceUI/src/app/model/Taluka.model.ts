import { District } from "./District.model";

export class Taluka {
  talukaId!: number;
  talukaName!: string;
  talukaDistrict!: District;
}
