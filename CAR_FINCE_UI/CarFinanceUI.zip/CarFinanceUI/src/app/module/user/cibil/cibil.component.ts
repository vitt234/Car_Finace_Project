import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cibil',
  templateUrl: './cibil.component.html',
  styleUrls: ['./cibil.component.css']
})
export class CibilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
