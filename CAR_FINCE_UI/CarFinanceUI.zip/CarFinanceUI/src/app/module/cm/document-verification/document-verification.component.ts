import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-document-verification',
  templateUrl: './document-verification.component.html',
  styleUrls: ['./document-verification.component.css']
})
export class DocumentVerificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
