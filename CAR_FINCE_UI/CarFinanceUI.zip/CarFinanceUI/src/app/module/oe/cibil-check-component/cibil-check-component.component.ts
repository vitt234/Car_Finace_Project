import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cibil-check-component',
  templateUrl: './cibil-check-component.component.html',
  styleUrls: ['./cibil-check-component.component.css']
})
export class CibilCheckComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
