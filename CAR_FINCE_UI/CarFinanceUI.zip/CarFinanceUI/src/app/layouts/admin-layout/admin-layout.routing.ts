
import { Routes } from '@angular/router';
import { AHModule } from 'app/module/ah/ah.module';


export const AdminLayoutRoutes: Routes = [



];
