package com.cjc.app.carLoan.disbursement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarFinanceDisbursementModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
