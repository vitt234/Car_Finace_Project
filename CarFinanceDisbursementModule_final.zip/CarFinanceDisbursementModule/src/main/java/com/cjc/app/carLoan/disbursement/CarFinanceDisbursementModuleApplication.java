package com.cjc.app.carLoan.disbursement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarFinanceDisbursementModuleApplication 
{

	public static void main(String[] args)
	{
		SpringApplication.run(CarFinanceDisbursementModuleApplication.class, args);
	}

}
